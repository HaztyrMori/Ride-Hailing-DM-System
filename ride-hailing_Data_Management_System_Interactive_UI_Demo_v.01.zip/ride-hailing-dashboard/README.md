# 香港網約車數據管理系統 — HTML prototype

Open `index.html` directly, or serve this directory locally:

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

## React migration notes

The prototype deliberately separates shell, view renderers, data constants, and event handling. Each `render*View()` function in `app.js` maps cleanly to a React page component, while repeated patterns such as cards, tables, filters, tabs, KPI blocks, and dialogs can become shared components. CSS design tokens live at the top of `styles.css`.
