const appState = {
  language: 'zh',
  view: 'operator',
  complianceTab: 'overview',
  complianceMetric: 'orders',
  complianceHistoryRange: '365',
  compliancePeriod: 'day',
  complianceOperators: ['營運商 A', '營運商 B', '營運商 C', '營運商 D', '營運商 E', '營運商 F'],
  complianceException: 'all',
  topOperator: 'all',
  topAnomaly: 'all',
  uploadStatus: 'all',
  uploadRange: '90',
  range: '14',
  tripOperator: 'all',
  tripHistoryView: 'bar',
  operator: '全部',
  vehicleMetric: 'active',
  vehiclePeriod: 'yesterday',
  vehicleHistoryRange: '90',
  inactivePageSize: '5',
  inactiveStatus: 'all',
  sidebarCollapsed: false,
};

const vehiclePeriodData = {
  yesterday: {
    label: '昨天', active: '6,940', licensedInactive: '910', unregistered: '4,253',
    activeRate: 57.3, activeRateLabel: '57.3%', licensedTotal: '7,850', registrationRate: '78.5%', operatingRate: '88.4%',
    trips: ['2', '3', '0'], inactiveDays: ['1 天', '5 天', '7 天'],
  },
  week: {
    label: '過去 7 日', active: '7,210', licensedInactive: '780', unregistered: '4,113',
    activeRate: 59.6, activeRateLabel: '59.6%', licensedTotal: '7,990', registrationRate: '79.9%', operatingRate: '90.2%',
    trips: ['8', '11', '0'], inactiveDays: ['7 天', '12 天', '14 天'],
  },
  month: {
    label: '過去 30 日', active: '7,480', licensedInactive: '650', unregistered: '3,973',
    activeRate: 61.8, activeRateLabel: '61.8%', licensedTotal: '8,130', registrationRate: '81.3%', operatingRate: '92.0%',
    trips: ['36', '42', '1'], inactiveDays: ['30 天', '35 天', '41 天'],
  },
};

const operators = [
  { name: '營運商 A', compliance: '96.2%', aggregator: '是', drivers: '—', licence: 'RHL-***-001', start: '2024-01-01', end: '2026-01-01' },
  { name: '營運商 B', compliance: '94.8%', aggregator: '否', drivers: '9,120', licence: 'RHL-***-002', start: '2024-02-15', end: '2026-02-15' },
  { name: '營運商 C', compliance: '88.5%', aggregator: '否', drivers: '7,430', licence: 'RHL-***-003', start: '2024-03-01', end: '2026-03-01' },
  { name: '營運商 D', compliance: '97.1%', aggregator: '是', drivers: '—', licence: 'RHL-***-004', start: '2024-04-10', end: '2026-04-10' },
  { name: '營運商 E', compliance: '91.4%', aggregator: '是', drivers: '—', licence: 'RHL-***-005', start: '2024-05-05', end: '2026-05-05' },
  { name: '營運商 F', compliance: '89.2%', aggregator: '否', drivers: '5,760', licence: 'RHL-***-006', start: '2024-06-01', end: '2026-06-01' },
];

const tripCompanies = [
  ['營運商 A', '192 (30%)'], ['營運商 B', '128 (20%)'], ['營運商 C', '96 (15%)'],
  ['營運商 D', '83 (13%)'], ['營運商 E', '76 (12%)'], ['營運商 F', '63 (10%)'],
];

const tripHistorySummary = {
  7: { total: '3,864', average: '552', max: '638' },
  14: { total: '7,395', average: '528', max: '638' },
  30: { total: '15,570', average: '519', max: '670' },
};

const uploadRows = [
  ['7月31日 · 14:32', '2025-07-30', 'compliance_07_31_2026_3.xlsx', '所有營運商', 'A. Smith', '10,000', '0', '警告'],
  ['7月30日 · 09:10', '2025-07-29', 'compliance_07_30_2026_1.xlsx', '營運商 C', 'J. Wong', '10,000', '0', '有效'],
  ['7月28日 · 16:45', '2025-07-27', 'compliance_07_28_2026_4.xlsx', '所有營運商', 'S. Chan', '10,000', '0', '警告'],
  ['7月24日 · 11:20', '2025-07-23', 'compliance_07_24_2026_1.xlsx', '所有營運商', 'M. Lee', '10,000', '0', '有效'],
  ['7月17日 · 15:02', '2025-07-16', 'compliance_07_17_2026_1.xlsx', '營運商 A', 'K. Law', '10,000', '0', '有效'],
];

const el = (selector, root = document) => root.querySelector(selector);
const all = (selector, root = document) => [...root.querySelectorAll(selector)];

function donut(value, color = '#0e9db4', secondary = '#f4a20d', tooltip = '') {
  const tooltipLines = tooltip.split('|').filter(Boolean).map(line => `<span>${line}</span>`).join('');
  const tooltipMarkup = tooltip ? `<span class="donut-tooltip">${tooltipLines}</span>` : '';
  const accessibility = tooltip ? `tabindex="0" aria-label="${tooltip.replaceAll('|', '，')}"` : '';
  return `<div class="donut" ${accessibility} style="--value:${value};--donut:${color};--donut-alt:${secondary}">${tooltipMarkup}</div>`;
}

function operatorDonut(entries) {
  let cursor = 0;
  const segments = entries.map(entry => {
    const start = cursor;
    cursor += entry.share ?? (100 / entries.length);
    return `${entry.color} ${start}% ${cursor}%`;
  }).join(',');
  const tooltip = entries.map(entry => `<span><i style="background:${entry.color}"></i>${entry.label}　${entry.value}</span>`).join('');
  return `<div class="donut operator-donut" tabindex="0" aria-label="${entries.map(entry => `${entry.label} ${entry.value}`).join('，')}" style="background:conic-gradient(${segments})"><span class="donut-tooltip">${tooltip}</span></div>`;
}

function operatorLegend(entries) {
  return `<div class="operator-mini-legend">${entries.map(entry => `<span><i style="background:${entry.color}"></i>${entry.label.replace('營運商 ', '')}</span>`).join('')}</div>`;
}

function pageHeading(eyebrow, title, subtitle, actions = '') {
  return `<div class="page-heading">
    <div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p>${subtitle}</p></div>
    ${actions ? `<div class="heading-actions">${actions}</div>` : ''}
  </div>`;
}

function renderTripHistory(range, operator = 'all', view = 'bar') {
  const days = Number(range);
  const operatorIndex = operator === 'all' ? -1 : Number(operator);
  const operatorFactor = operatorIndex < 0 ? 1 : [0.29, 0.2, 0.17, 0.14, 0.11, 0.09][operatorIndex];
  const endDate = new Date(Date.UTC(2026, 6, 14));
  const entries = Array.from({ length: days }, (_, index) => {
    const date = new Date(endDate);
    date.setUTCDate(endDate.getUTCDate() - (days - 1 - index));
    const baseCompleted = 47 + ((index * 13 + days) % 48);
    const baseOnline = Math.max(24, baseCompleted - 18 - ((index * 5) % 12));
    const completed = Math.round(baseCompleted * operatorFactor);
    const online = Math.round(baseOnline * operatorFactor);
    return {
      completed,
      online,
      label: `${date.getUTCMonth() + 1}/${String(date.getUTCDate()).padStart(2, '0')}`,
    };
  });
  const summary = operatorIndex < 0 ? tripHistorySummary[days] : {
    total: entries.reduce((sum, item) => sum + item.completed, 0).toLocaleString(),
    average: Math.round(entries.reduce((sum, item) => sum + item.completed, 0) / days).toLocaleString(),
    max: Math.max(...entries.map(item => item.completed)).toLocaleString(),
  };
  const chartWidth = `${Math.max(620, days * 72)}px`;
  const maxValue = Math.max(...entries.flatMap(item => [item.completed, item.online]), 1);
  const bars = `<div class="bar-chart" style="min-width:${chartWidth}">${entries.map(entry => `<div class="bar-group"><i style="height:${Math.max(5, entry.completed / maxValue * 100)}%" title="${entry.label} 完成行程數 ${entry.completed}"></i><b style="height:${Math.max(5, entry.online / maxValue * 100)}%" title="${entry.label} 曾上線車輛數 ${entry.online}"></b><small>${entry.label}</small></div>`).join('')}</div>`;
  const svgWidth = Math.max(620, days * 72);
  const pointX = index => 34 + index * ((svgWidth - 68) / Math.max(1, days - 1));
  const pointY = value => 148 - (value / maxValue * 112);
  const line = `<svg class="trip-line-chart" style="min-width:${svgWidth}px" viewBox="0 0 ${svgWidth} 180" role="img" aria-label="行程歷史折線圖"><line x1="24" y1="150" x2="${svgWidth - 20}" y2="150" class="trip-axis"/>${entries.map((entry, index) => `<text x="${pointX(index)}" y="171" text-anchor="middle">${entry.label}</text>`).join('')}<polyline points="${entries.map((entry, index) => `${pointX(index)},${pointY(entry.completed)}`).join(' ')}" class="trip-line completed-line"/><polyline points="${entries.map((entry, index) => `${pointX(index)},${pointY(entry.online)}`).join(' ')}" class="trip-line online-line"/>${entries.map((entry, index) => `<circle cx="${pointX(index)}" cy="${pointY(entry.completed)}" r="3.5" class="completed-point"><title>${entry.label} 完成行程數 ${entry.completed}</title></circle><circle cx="${pointX(index)}" cy="${pointY(entry.online)}" r="3.5" class="online-point"><title>${entry.label} 曾上線車輛數 ${entry.online}</title></circle>`).join('')}</svg>`;
  const table = `<div class="trip-table-wrap"><table class="trip-history-table"><thead><tr><th>日期</th><th>完成行程數</th><th>曾上線車輛數</th></tr></thead><tbody>${entries.map(entry => `<tr><td>${entry.label}</td><td>${entry.completed}</td><td>${entry.online}</td></tr>`).join('')}</tbody></table></div>`;
  const content = view === 'line' ? line : view === 'table' ? table : bars;

  return `<div class="history-visual"><div class="history-chart-scroll">${content}</div><div class="history-view-toggle" role="group" aria-label="圖表顯示方式"><button type="button" data-history-view="line" class="${view === 'line' ? 'active' : ''}" title="折線圖" aria-label="折線圖">⌁</button><button type="button" data-history-view="bar" class="${view === 'bar' ? 'active' : ''}" title="柱狀圖" aria-label="柱狀圖">▮</button><button type="button" data-history-view="table" class="${view === 'table' ? 'active' : ''}" title="表格" aria-label="表格">▦</button></div></div>
    <div class="summary-pills"><span>∑ 合計完成行程數 <b>${summary.total}</b></span><span>⊘ 平均完成行程數 <b>${summary.average}</b></span><span>↑ 最高單日完成行程數 <b>${summary.max}</b></span></div>
    <div class="trip-legend"><span><i class="completed-key"></i>完成行程數</span><span><i class="online-key"></i>曾上線車輛數</span></div>`;
}

function renderComplianceChart(metric, includedOperators = operators.map(operator => operator.name), range = '365') {
  const colors = ['#1686d9', '#08a979', '#f2a10a', '#7258c8', '#e65a57', '#25a7bd'];
  const bases = [96.2, 94.8, 88.5, 97.1, 91.4, 89.2];
  const metricOffsets = { orders: 0, drivers: 0.8, operators: 1.2, vehicles: -0.6 };
  const patterns = [
    [-1.2, -0.4, 0.5, -0.2, 0.8, 1.4, 1.8],
    [-0.8, 0.3, -0.4, 0.9, 0.2, 1.1, 1.5],
    [0.2, 0.8, 1.5, 0.6, 1.9, 2.4, 2.8],
    [0.5, -0.6, -1.1, 0.2, 0.9, 0.4, 1.3],
    [-0.4, 0.6, 1.2, 0.3, 1.5, 2.1, 1.7],
    [0.8, 0.1, 0.9, 1.6, 1.0, 2.0, 2.5],
  ];
  const x = index => 74 + index * 143;
  const y = value => 24 + ((100 - value) / 20) * 196;
  const series = bases.map((base, seriesIndex) => ({
    name: `營運商 ${String.fromCharCode(65 + seriesIndex)}`,
    color: colors[seriesIndex],
    values: patterns[seriesIndex].map(value => Math.min(99.6, Math.max(80, base + value + metricOffsets[metric]))),
  })).filter(item => includedOperators.includes(item.name));
  const rangeLabels = {
    7: ['8/18', '8/19', '8/20', '8/21', '8/22', '8/23', '8/24'],
    30: ['7/26', '7/31', '8/05', '8/10', '8/15', '8/20', '8/24'],
    90: ['5/26', '6/10', '6/25', '7/10', '7/25', '8/09', '8/24'],
    365: ['2025/8', '2025/10', '2025/12', '2026/2', '2026/4', '2026/6', '2026/8'],
  };
  const axisLabels = rangeLabels[range] || rangeLabels[365];

  return `<div class="compliance-chart-wrap"><svg class="compliance-svg" viewBox="0 0 1000 270" role="img" aria-label="已選營運商在過去 ${range} 天的合規率趨勢">
    ${[100, 95, 90, 85, 80].map(value => `<line x1="60" y1="${y(value)}" x2="950" y2="${y(value)}" class="chart-grid-line"/><text x="48" y="${y(value) + 4}" text-anchor="end" class="chart-axis-label">${value}%</text>`).join('')}
    ${axisLabels.map((label, index) => `<text x="${x(index)}" y="249" text-anchor="middle" class="chart-axis-label">${label}</text>`).join('')}
    ${series.map(item => `<polyline points="${item.values.map((value, index) => `${x(index)},${y(value)}`).join(' ')}" fill="none" stroke="${item.color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>${item.values.map((value, index) => `<circle cx="${x(index)}" cy="${y(value)}" r="4" fill="white" stroke="${item.color}" stroke-width="2"><title>${item.name} · ${index + 1}月 · ${value.toFixed(1)}%</title></circle>`).join('')}`).join('')}
  </svg></div><div class="compliance-chart-legend">${series.map(item => `<span><i style="background:${item.color}"></i>${item.name}</span>`).join('')}</div>`;
}

function renderOperatorView() {
  const operatorPalette = ['#1686d9', '#13a58b', '#7258c8', '#f2a10a', '#3474b9', '#df655d'];
  const registrationEntries = operators.map((operator, index) => ({
    label: operator.name,
    value: `${[3389, 2663, 2179, 1694, 1210, 968][index].toLocaleString()}（${[28, 22, 18, 14, 10, 8][index]}%）`,
    share: [28, 22, 18, 14, 10, 8][index],
    color: operatorPalette[index],
  }));
  const vehicleEntries = operators.map((operator, index) => ({
    label: operator.name,
    value: `${[26, 21, 18, 15, 11, 9][index]}%`,
    share: [26, 21, 18, 15, 11, 9][index],
    color: operatorPalette[index],
  }));
  const rows = operators
    .filter(row => appState.operator === '全部' || row.name === appState.operator)
    .map((row, index) => `<tr>
      <td><strong>${row.name}</strong></td><td><span>${row.compliance}</span></td>
      <td>${row.aggregator}</td><td>${row.drivers}</td><td>${row.licence}</td><td>${row.start}</td><td>${row.end}</td>
      <td><button class="link-btn" data-operator-detail="${index}">詳情</button></td>
    </tr>`).join('');

  return `<section class="view view-operator">
    ${pageHeading('香港網約車數據管理系統 / 決策支援', '營運商總覽', '檢視全體營運商的註冊及合規指標')}
    <div class="kpi-grid three">
      <article class="kpi-card donut-card">${operatorDonut(registrationEntries)}<div><span>已註冊司機帳戶總數</span><strong>12,103</strong></div></article>
      <article class="kpi-card donut-card">${donut(97.9, '#0aaa78', '#ed4b4b', '合規　97.9%|不合規　2.1%')}<div><span>平均合規率</span><strong>97.9%</strong><small><i class="dot teal"></i>合規　<i class="dot red"></i>不合規</small></div></article>
      <article class="kpi-card donut-card">${operatorDonut(vehicleEntries)}<div><span>每日平均營運車輛數（30日內）</span><strong>4,892</strong></div></article>
    </div>
    <article class="card table-card">
      <header class="card-header">
        <div><h2>營運商註冊資料</h2><p>牌照及營運資料概覽</p></div>
        <div class="table-tools"><label>營運商
          <select id="operator-filter"><option>全部</option>${operators.map(o => `<option>${o.name}</option>`).join('')}</select>
        </label><span>共 ${operators.length} 筆資料</span><button class="secondary-btn export-btn">匯出</button></div>
      </header>
      <div class="table-scroll operator-list-scroll"><table><thead><tr><th>營運商名稱</th><th>合規率</th><th>聚合營運商</th><th>司機數量</th><th>牌照編號</th><th>牌照生效日</th><th>牌照屆滿日</th><th>詳情</th></tr></thead><tbody>${rows}</tbody></table></div>
    </article>
  </section>`;
}

function renderFleetView() {
  return `<section class="view fleet-view">
    <div class="date-title"><h1>2026-07-14 數據</h1></div>
    <div class="fleet-layout">
      <aside class="card completed-panel">
        <p>完成行程總數</p><strong>638</strong><small>較 2026-07-13 <b>▲ 4.2%</b></small>
        <div class="rank-list">${tripCompanies.map((c, i) => `<div><span><i>${i + 1}</i>${c[0]}</span><b>${c[1]}</b></div>`).join('')}</div>
      </aside>
      <section class="card map-card">
        <div class="map-kpis">
          <section class="map-kpi-section" aria-label="司機營運狀態"><div><strong>8,000</strong><span>在線司機</span></div><div><strong>500</strong><span>已接單司機</span></div><div><strong>7,500</strong><span>等待接單司機</span></div></section>
          <section class="map-kpi-section" aria-label="乘客服務時長"><div><strong>6.8<small> 分鐘</small></strong><span>乘客平均等候時長</span></div><div><strong>1.3<small> 分鐘</small></strong><span>乘客叫車配對時長</span></div><div><strong>5.5<small> 分鐘</small></strong><span>乘客等待接載時間</span></div></section>
        </div>
        <div class="map-stage">
          <img src="assets/hong-kong-map.png" alt="香港地理營運地圖" />
          <div class="map-summary"><span>2026-07-14 行政區域數據</span><h3>全港總覽</h3><p><i class="dot teal"></i>上線車輛數量：<b>5,984</b></p><p><i class="dot blue"></i>待派單司機數量：<b>2,480</b></p><p><i class="dot red"></i>待派單乘客數量：<b>286</b></p></div>
          <div class="map-label">地圖佔位符</div><div class="zoom"><button>＋</button><button>−</button></div>
        </div>
      </section>
      <section class="card monthly-card">
        <h2>2026 年 7 月重點營運指標</h2>
        <table class="mini-table"><thead><tr><th>重點指標</th><th>本月數據</th><th>較上月同期</th></tr></thead><tbody>
          <tr><td>車輛日均訂單量</td><td>18.6 單</td><td class="positive">+5.2%</td></tr>
          <tr><td>平均等候時長</td><td>6.8 分鐘</td><td class="negative">-0.6 分鐘</td></tr>
          <tr><td>取消訂單量</td><td>34 單</td><td class="negative">-3 單</td></tr>
          <tr><td>跨平台曾上線司機</td><td>1,286 人</td><td class="positive">+42 人</td></tr>
        </tbody></table>
      </section>
      <section class="card history-card">
        <header><h2>行程歷史</h2><div class="history-filters"><select id="trip-range"><option value="7">過去 7 日</option><option value="14">過去 14 日</option><option value="30">過去 30 日</option></select><select id="trip-operator"><option value="all">全部營運商</option>${operators.map((item, index) => `<option value="${index}">${item.name}</option>`).join('')}</select></div></header>
        <div id="trip-history-content">${renderTripHistory(appState.range, appState.tripOperator, appState.tripHistoryView)}</div>
      </section>
      <section class="card operator-rank"><div class="segmented"><button class="active">完成行程量</button><button>曾上線車輛數</button></div>
        <div class="operator-rank-scroll">${tripCompanies.map((c, i) => `<div class="wide-rank"><span><i>${i + 1}</i>${c[0]}</span><strong>${[1490, 1280, 1060, 990, 840, 760][i]}</strong></div>`).join('')}</div>
      </section>
    </div>
  </section>`;
}

function renderVehiclesView() {
  const periodData = vehiclePeriodData[appState.vehiclePeriod];
  const vehicleHistory = {
    7: { labels: ['7/08', '7/09', '7/10', '7/11', '7/12', '7/13', '7/14'], values: [64, 72, 59, 81, 70, 88, 76] },
    30: { labels: ['6/15', '6/20', '6/25', '6/30', '7/05', '7/10', '7/14'], values: [58, 69, 63, 77, 71, 86, 80] },
    60: { labels: ['5/16', '5/26', '6/05', '6/15', '6/25', '7/05', '7/14'], values: [51, 65, 60, 73, 68, 82, 78] },
    90: { labels: ['4/16', '5/01', '5/16', '5/31', '6/15', '6/30', '7/14'], values: [47, 59, 55, 69, 64, 79, 75] },
  }[appState.vehicleHistoryRange];
  const periodOrderMax = { yesterday: 3, week: 15, month: 42 }[appState.vehiclePeriod];
  const inactiveRows = Array.from({ length: 150 }, (_, index) => {
    const offline = index % 3 === 2;
    const dayOffset = (index % 24) + 1;
    const date = new Date(Date.UTC(2026, 6, 23));
    date.setUTCDate(date.getUTCDate() - dayOffset);
    return {
      plate: `${['TX', 'VN', 'SW', 'RL', 'KM', 'JP'][index % 6]} ${String(3821 + index * 37).slice(-4)}`,
      driver: `${['陳', '李', '王', '張', '劉', '林'][index % 6]}**`,
      status: offline ? 'offline' : 'licensedInactive',
      statusLabel: offline ? '未營運' : '有營運但未活躍',
      orders: offline ? 0 : (index * 7 + 2) % periodOrderMax,
      days: `${offline ? 7 + (index % 18) : 1 + (index % 6)} 天`,
      lastOnline: `${date.toISOString().slice(0, 10)} ${String(8 + index % 11).padStart(2, '0')}:${String((index * 7) % 60).padStart(2, '0')}:${String((index * 13) % 60).padStart(2, '0')}`,
    };
  }).filter(row => appState.inactiveStatus === 'all' || row.status === appState.inactiveStatus).slice(0, Number(appState.inactivePageSize));
  return `<section class="view vehicle-view">
    ${pageHeading('香港網約車數據管理系統 / 決策支援', '行程統計', '掌握車輛活躍度、未活躍車輛及長期變化')}
    <article class="card range-card"><h3>活躍門檻定義</h3><p>車輛平均每日完成 <input value="4" aria-label="每日完成行程門檻" /> 行程，選擇時間 <select id="vehicle-period"><option value="yesterday">昨天</option><option value="week">過去 7 日</option><option value="month">過去 30 日</option></select></p></article>
    <div class="kpi-grid three compact">
      <article class="kpi-card"><span>活躍車輛 · <b data-vehicle-bind="label">${periodData.label}</b></span><strong data-vehicle-bind="active">${periodData.active}</strong></article><article class="kpi-card"><span>有營運但未活躍 · <b data-vehicle-bind="label">${periodData.label}</b></span><strong data-vehicle-bind="licensedInactive">${periodData.licensedInactive}</strong></article><article class="kpi-card alert"><span>未營運車輛 · <b data-vehicle-bind="label">${periodData.label}</b></span><strong data-vehicle-bind="unregistered">${periodData.unregistered}</strong></article>
    </div>
    <article class="card distribution-card"><header class="card-header"><div><h2>車輛狀態分佈</h2><p>目前範圍：<b data-vehicle-bind="label">${periodData.label}</b> · 註冊車輛總數 12,103</p></div></header>
      <div class="distribution-body">
        <div class="big-donut">${donut(periodData.activeRate, '#0c81db', '#ffab08')}<div><strong>12,103</strong><span>註冊車輛總數</span></div></div>
        <div class="legend"><p><i class="dot blue"></i>活躍車輛 <b data-vehicle-bind="activeRateLabel">${periodData.activeRateLabel}</b></p><p><i class="dot orange"></i>有營運但未活躍 <b data-vehicle-bind="licensedInactive">${periodData.licensedInactive}</b></p><p><i class="dot red"></i>未營運車輛 <b data-vehicle-bind="unregistered">${periodData.unregistered}</b></p></div>
        <div class="conversion-flow">
          <div class="conversion-row first-row">
            <div class="funnel-level registered-level"><span>已註冊車輛總數</span><b>12,103 輛</b></div>
            <div class="conversion-note"><p>級間轉化率：營運率 <strong data-vehicle-bind="registrationRate">${periodData.registrationRate}</strong></p><small class="negative">未營運車輛：<b data-vehicle-bind="unregistered">${periodData.unregistered}</b> 輛</small></div>
          </div>
          <div class="conversion-row second-row">
            <div class="funnel-level licensed-level"><span>有營運總數</span><b><span data-vehicle-bind="licensedTotal">${periodData.licensedTotal}</span> 輛</b></div>
            <div class="conversion-note"><p>級間轉化率：營運活躍率 <strong data-vehicle-bind="operatingRate">${periodData.operatingRate}</strong></p><small class="orange-text">有營運但未活躍：<b data-vehicle-bind="licensedInactive">${periodData.licensedInactive}</b> 輛</small></div>
          </div>
          <div class="conversion-row third-row">
            <div class="funnel-level active-level"><span>活躍車輛數</span><b><span data-vehicle-bind="active">${periodData.active}</span> 輛</b></div>
            <div class="overall-rate"><span>總體活躍率（活躍車輛/在冊總數）</span><div class="overall-rate-value"><strong data-vehicle-bind="activeRateLabel">${periodData.activeRateLabel}</strong><small>（<span data-vehicle-bind="active">${periodData.active}</span> / 12,103）</small></div></div>
          </div>
        </div>
      </div>
    </article>
    <article class="card trend-card"><header><div><h2>車輛狀態歷史</h2><p>按所選期間統計車輛狀態數量變化</p></div><select id="vehicle-history-range" aria-label="車輛狀態歷史範圍"><option value="7">過去 7 日</option><option value="30">過去 30 日</option><option value="60">過去 60 日</option><option value="90">過去 90 日</option></select></header><div class="trend-bars">${vehicleHistory.values.map((h, i) => `<div><i style="height:${h}%"></i><b style="height:${Math.max(24, h - 18 - (i % 2) * 3)}%"></b><em style="height:${Math.max(20, h - 28 + (i % 3) * 2)}%"></em><small>${vehicleHistory.labels[i]}</small></div>`).join('')}</div></article>
    <article class="card inactive-detail-card">
      <header class="card-header"><div><h2>非活躍車輛詳情</h2><p>依據最新篩選條件顯示非活躍車輛營運效率</p></div><div class="inactive-table-tools"><label>每頁行數 <select id="inactive-page-size"><option value="5">5</option><option value="15">15</option><option value="35">35</option><option value="50">50</option></select></label><label>狀態 <select id="inactive-status"><option value="all">全部</option><option value="licensedInactive">有營運但未活躍</option><option value="offline">未營運</option></select></label><button class="primary-btn" id="apply-inactive-filter">套用</button><button class="secondary-btn export-btn">匯出</button></div></header>
      <div class="table-scroll inactive-vehicle-table"><table><thead><tr><th>車牌號碼</th><th>司機姓名</th><th>狀態</th><th>期間訂單數</th><th>累計非活躍天數</th><th>最近上線時間</th></tr></thead><tbody>${inactiveRows.map(row => `<tr><td>${row.plate}</td><td>${row.driver}</td><td><span class="status ${row.status === 'offline' ? 'danger' : 'warning'}">${row.statusLabel}</span></td><td>${row.orders}</td><td>${row.days}</td><td>${row.lastOnline}</td></tr>`).join('')}</tbody></table></div>
    </article>
  </section>`;
}

function renderComplianceOverview() {
  const periodMetrics = {
    day: { orderRate: '87.05%', orderCount: '18,281 / 21,000', overallRate: '99.90%', overallCount: '9,990 / 10,000', drivers: '10' },
    week: { orderRate: '89.40%', orderCount: '131,418 / 147,000', overallRate: '98.70%', overallCount: '9,870 / 10,000', drivers: '18' },
    month: { orderRate: '91.20%', orderCount: '574,560 / 630,000', overallRate: '97.90%', overallCount: '9,790 / 10,000', drivers: '24' },
  };
  const metrics = periodMetrics[appState.compliancePeriod];
  const visibleOperators = operators.map((operator, index) => ({ operator, index })).filter(item => appState.complianceOperators.includes(item.operator.name));
  const anomalyTypes = [
    { value: 'driverNoLicence', label: '司機無許可證' },
    { value: 'vehicleNoLicence', label: '車輛無許可證' },
    { value: 'bothNoLicence', label: '司機和車輛無許可證' },
    { value: 'unbound', label: '司機和車輛未綁定' },
  ];
  const exceptionRows = visibleOperators.map(item => ({ ...item, anomaly: anomalyTypes[item.index % anomalyTypes.length] })).filter(item => appState.complianceException === 'all' || item.anomaly.value === appState.complianceException);
  const topRecords = Array.from({ length: 10 }, (_, index) => ({
    operator: operators[index % operators.length].name,
    driver: `${String.fromCharCode(65 + index)}1****${95 - index}`,
    plate: ['AB 1234','CD 5678','EF 8901','GH 9456','JK 3210','LM 7788','NP 4567','QR 6123','ST 2345','UV 8890'][index],
    driverNoLicence: 3 - (index % 3), vehicleNoLicence: 5 - (index % 4), bothNoLicence: 2 - (index % 2), unbound: 1 + (index % 3),
  })).filter(record => appState.complianceOperators.includes(record.operator) && (appState.topOperator === 'all' || record.operator === appState.topOperator));
  if (appState.topAnomaly !== 'all') topRecords.sort((a, b) => b[appState.topAnomaly] - a[appState.topAnomaly]);

  return `<div class="compliance-overview">
    <article class="card filter-bar"><label>特別期間<select id="compliance-period"><option value="day">昨天</option><option value="week">過去 7 日</option><option value="month">過去 30 日</option></select></label><label>營運商<div id="compliance-operator-multiselect" class="multi-select"><button id="compliance-operator-trigger" type="button" aria-haspopup="true" aria-expanded="false"><span>${appState.complianceOperators.length === operators.length ? '所有營運商' : appState.complianceOperators.join('、')}</span><b>⌄</b></button><div class="multi-select-menu"><label><input type="checkbox" value="all" ${appState.complianceOperators.length === operators.length ? 'checked' : ''}/>所有營運商</label>${operators.map(operator => `<label><input type="checkbox" value="${operator.name}" ${appState.complianceOperators.includes(operator.name) ? 'checked' : ''}/>${operator.name}</label>`).join('')}</div></div></label><span></span><button class="secondary-btn export-btn">匯出不合規報告</button><button class="ghost-btn reset-compliance">重設</button><button class="primary-btn apply-filter">套用</button></article>
    <div class="kpi-grid three compact"><article class="kpi-card"><span>訂單合規率（合規訂單數/總訂單數）</span><strong>${metrics.orderRate} <small>(${metrics.orderCount})</small></strong></article><article class="kpi-card"><span>整體合規率（合規司機/曾接單的司機總數）</span><strong>${metrics.overallRate} <small>(${metrics.overallCount})</small></strong></article><article class="kpi-card"><span>不合規司機</span><strong>${metrics.drivers}</strong></article></div>
    <div class="split-cards"><article class="card compliance-detail"><h2>合規詳情</h2><p>合規率 &gt;95% 為綠色（優），合規率 &lt;85% 為紅色（劣）</p><div class="compliance-operator-scroll"><table><thead><tr><th>營運商</th><th>合規單</th><th>不合規單</th><th>合規百分比</th><th>合規司機/車輛</th><th>不合規司機/車輛</th><th>合規百分比</th></tr></thead><tbody>${visibleOperators.map(({ operator, index: i }) => `<tr><td>${operator.name}</td><td>${[1520, 1180, 620, 1390, 940, 760][i]}</td><td>${[68, 74, 140, 42, 91, 116][i]}</td><td class="${i === 2 || i === 5 ? 'negative' : 'positive'}">${['95.7%', '94.1%', '81.6%', '97.1%', '90.3%', '84.2%'][i]}</td><td>${[168, 142, 83, 151, 112, 96][i]}</td><td>${[8, 9, 10, 5, 11, 14][i]}</td><td class="${i === 2 || i === 5 ? 'negative' : 'positive'}">${['95.5%', '94.0%', '82.8%', '96.8%', '91.1%', '83.4%'][i]}</td></tr>`).join('')}</tbody></table></div></article>
      <article class="card exceptions"><header><h2>司機及車輛異常記錄</h2><select id="exception-type" aria-label="篩選異常類型"><option value="all">所有異常類型</option>${anomalyTypes.map(type => `<option value="${type.value}">${type.label}</option>`).join('')}</select></header><div class="exceptions-scroll"><table><thead><tr><th>記錄編號</th><th>時間</th><th>營運商</th><th>操作</th></tr></thead><tbody>${exceptionRows.map(({ operator, index: i, anomaly }) => `<tr><td>VHD-${20391 + i * 611}</td><td>07-${25 - i} ${['14:32','09:15','16:05','11:48','18:20','08:42'][i]}</td><td>${operator.name}</td><td><button class="link-btn driver-detail" data-anomaly="${anomaly.label}">查看詳情</button></td></tr>`).join('')}</tbody></table></div></article></div>
    <article class="card compliance-history"><header class="card-header"><div><h2>合規歷史統計</h2><p>比較已選營運商在指定期間內的合規率</p></div><div class="compliance-history-controls"><label class="metric-select-label">統計指標<select id="compliance-metric-select"><option value="orders">訂單</option><option value="drivers">司機合規</option><option value="operators">營運商</option><option value="vehicles">車輛合規</option></select></label><label class="metric-select-label">過去<select id="compliance-history-range"><option value="7">7 日</option><option value="30">30 日</option><option value="90">90 日</option><option value="365">365 日</option></select></label></div></header><div id="compliance-chart">${renderComplianceChart(appState.complianceMetric, appState.complianceOperators, appState.complianceHistoryRange)}</div></article>
    <article class="card top-table"><h2>Top 10 不合規/異常司機</h2><div class="table-tools"><select id="top-operator"><option value="all">所有已選營運商</option>${visibleOperators.map(({ operator }) => `<option value="${operator.name}">${operator.name}</option>`).join('')}</select><select id="top-anomaly"><option value="all">所有異常類型</option>${anomalyTypes.map(type => `<option value="${type.value}">${type.label}</option>`).join('')}</select><input placeholder="搜尋司機或車牌號碼"/><button class="primary-btn">套用</button></div><div class="table-scroll"><table><thead><tr><th>序號</th><th>營運商</th><th>司機許可證號</th><th>車牌號碼</th><th>司機無許可證</th><th>車輛無許可證</th><th>司機和車輛無許可證</th><th>司機和車輛未綁定</th></tr></thead><tbody>${topRecords.map((record, i) => `<tr><td>${i + 1}</td><td>${record.operator}</td><td>${record.driver}</td><td>${record.plate}</td><td>${record.driverNoLicence}</td><td>${record.vehicleNoLicence}</td><td>${record.bothNoLicence}</td><td>${record.unbound}</td></tr>`).join('')}</tbody></table></div></article>
  </div>`;
}

function renderUploadHistory() {
  const rangeLimit = { 30: 3, 60: 4, 90: uploadRows.length }[Number(appState.uploadRange)];
  const filteredUploads = uploadRows.filter(row => appState.uploadStatus === 'all' || (appState.uploadStatus === 'valid' ? row[7] === '有效' : row[7] === '警告')).slice(0, rangeLimit);
  return `<div class="upload-history">
    <div class="kpi-grid two compact"><article class="kpi-card"><span>本月上傳</span><strong>12</strong></article><article class="kpi-card"><span>帶警告匯入</span><strong class="orange-text">0</strong></article></div>
    <div class="upload-summary-grid"><article class="card latest-upload"><header><div><h2>最近上傳驗證批次</h2><p>compliance_august_2026.xlsx · CNP-260803-0001</p></div><span class="status warning">需要覆查</span></header><div class="upload-counts"><div><span>總計</span><b>10,000</b></div><div><span>已匯入</span><b class="positive">10,000</b></div><div><span>警告</span><b class="orange-text">0</b></div></div><small>由系統管理員上傳 · 2026年8月5日 14:32 · 所有營運商</small></article>
      <article class="card warnings"><h2>0 個未解決警告</h2><p>這個批次沒有阻止匯入的驗證問題。</p><ul><li>0 個缺失牌照號碼</li><li>0 個無效身份證 · 0 個重複項</li><li>0 個未能識別的營運商編號</li></ul><button class="warning-btn">查看警告</button></article></div>
    <article class="card upload-table"><header class="card-header"><div><h2>上傳及驗證歷史</h2><p>目前顯示 ${filteredUploads.length} 個批次</p></div><div class="table-tools"><select id="upload-status"><option value="all">所有狀態</option><option value="valid">有效</option><option value="warning">警告</option></select><select id="upload-range"><option value="30">過去 30 日</option><option value="60">過去 60 日</option><option value="90">過去 90 日</option></select><button class="secondary-btn export-btn">匯出</button></div></header><div class="table-scroll"><table class="upload-history-table"><colgroup><col class="upload-time-col"/><col class="data-date-col"/><col class="file-name-col"/><col class="uploader-col"/><col class="imported-col"/><col class="error-col"/><col class="status-col"/><col class="action-col"/></colgroup><thead><tr><th>上傳時間</th><th>數據時間</th><th>檔案名</th><th>上傳者</th><th>已匯入行數</th><th>錯誤</th><th>狀態</th><th>操作</th></tr></thead><tbody>${filteredUploads.map(r => `<tr><td>${r[0].replace(' · ', ' ')}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[4]}</td><td>${r[5]}</td><td>${r[6]}</td><td><span class="status ${r[7] === '有效' ? 'success' : 'warning'}">${r[7]}</span></td><td><button class="link-btn validation-detail">查看結果</button></td></tr>`).join('')}</tbody></table></div></article>
  </div>`;
}

function renderComplianceView() {
  return `<section class="view compliance-view">
    ${pageHeading('決策支援 / 合規分析', '合規分析', '審查每次上傳、驗證質量、已匯入行數及未解決錯誤。', '<span class="freshness"><i></i>數據更新時間 2026-08-05 · 14:32</span><button class="primary-btn upload-data">↥ 上傳數據</button>')}
    <div class="large-tabs" role="tablist"><button role="tab" data-compliance-tab="overview" class="${appState.complianceTab === 'overview' ? 'active' : ''}">概覽</button><button role="tab" data-compliance-tab="history" class="${appState.complianceTab === 'history' ? 'active' : ''}">上傳歷史</button></div>
    ${appState.complianceTab === 'overview' ? renderComplianceOverview() : renderUploadHistory()}
  </section>`;
}

const renderers = { operator: renderOperatorView, fleet: renderFleetView, vehicles: renderVehiclesView, compliance: renderComplianceView };

function render() {
  const main = el('#main');
  main.innerHTML = renderers[appState.view]();
  document.body.dataset.view = appState.view;
  all('[data-view]').forEach(button => button.classList.toggle('active', button.dataset.view === appState.view));
  const decisionNav = el('.global-nav [data-section="decision"]');
  if (decisionNav) decisionNav.classList.toggle('active', appState.view !== 'fleet');
  const filter = el('#operator-filter');
  if (filter) filter.value = appState.operator;
  bindViewEvents();
  applyLanguage(appState.language);
}

function applyLanguage(language) {
  const english = language === 'en';
  document.documentElement.lang = english ? 'en' : 'zh-Hant';
  const sharedLabels = [
    ['.brand > span:last-child', english ? 'Hong Kong Ride-Hailing Data Management System' : '香港網約車數據管理系統'],
    ['.global-nav [data-view="fleet"]', english ? 'Operations Overview' : '營運概覽'],
    ['.global-nav [data-section="decision"]', english ? 'Decision Support' : '決策支援'],
    ['.admin-label', english ? 'Administrator' : '系統管理員'],
    ['.logout-btn', english ? '↪ Sign out' : '↪ 登出'],
    ['.side-heading strong', english ? 'Decision Support' : '決策支援'],
    ['.side-heading small', english ? '3 modules' : '3 個模組'],
  ];
  const navLabels = english ? ['Compliance Analysis', 'Operator Overview', 'Trip Statistics'] : ['合規分析', '營運商總覽', '行程統計'];
  sharedLabels.forEach(([selector, label]) => { const node = el(selector); if (node) node.textContent = label; });
  all('.side-nav button span:not(.nav-icon)').forEach((node, index) => { node.textContent = navLabels[index]; });
  const pageTitle = el('.view h1');
  if (pageTitle && english) pageTitle.textContent = { operator: 'Operator Overview', fleet: '2026-07-14 Data', vehicles: 'Trip Statistics', compliance: 'Compliance Analysis' }[appState.view];
}

function bindViewEvents() {
  const filter = el('#operator-filter');
  if (filter) filter.addEventListener('change', event => { appState.operator = event.target.value; render(); });
  all('[data-operator-detail]').forEach(button => button.addEventListener('click', () => showOperatorModal(operators[Number(button.dataset.operatorDetail)])));
  all('[data-compliance-tab]').forEach(button => button.addEventListener('click', () => { appState.complianceTab = button.dataset.complianceTab; render(); }));
  all('.upload-data').forEach(button => button.addEventListener('click', showUploadModal));
  all('.export-btn').forEach(button => button.addEventListener('click', () => toast('報告已準備下載（原型示範）')));
  all('.apply-filter').forEach(button => button.addEventListener('click', () => toast('篩選條件已套用')));
  all('.driver-detail').forEach(button => button.addEventListener('click', () => showDriverModal(button.dataset.anomaly)));
  all('.validation-detail').forEach(button => button.addEventListener('click', showValidationModal));
  all('.segmented button').forEach(button => button.addEventListener('click', () => {
    all('button', button.parentElement).forEach(b => b.classList.remove('active')); button.classList.add('active');
  }));
  const complianceMetricSelect = el('#compliance-metric-select');
  if (complianceMetricSelect) {
    complianceMetricSelect.value = appState.complianceMetric;
    complianceMetricSelect.addEventListener('change', event => {
      appState.complianceMetric = event.target.value;
      el('#compliance-chart').innerHTML = renderComplianceChart(appState.complianceMetric, appState.complianceOperators, appState.complianceHistoryRange);
    });
  }
  const complianceHistoryRange = el('#compliance-history-range');
  if (complianceHistoryRange) {
    complianceHistoryRange.value = appState.complianceHistoryRange;
    complianceHistoryRange.addEventListener('change', event => {
      appState.complianceHistoryRange = event.target.value;
      el('#compliance-chart').innerHTML = renderComplianceChart(appState.complianceMetric, appState.complianceOperators, appState.complianceHistoryRange);
    });
  }
  const compliancePeriod = el('#compliance-period');
  if (compliancePeriod) {
    compliancePeriod.value = appState.compliancePeriod;
    compliancePeriod.addEventListener('change', event => { appState.compliancePeriod = event.target.value; render(); });
  }
  const complianceOperatorTrigger = el('#compliance-operator-trigger');
  if (complianceOperatorTrigger) {
    complianceOperatorTrigger.addEventListener('click', event => {
      event.stopPropagation();
      const picker = el('#compliance-operator-multiselect');
      const open = picker.classList.toggle('open');
      complianceOperatorTrigger.setAttribute('aria-expanded', String(open));
    });
    all('#compliance-operator-multiselect input[type="checkbox"]').forEach(input => input.addEventListener('change', event => {
      event.stopPropagation();
      if (input.value === 'all') {
        appState.complianceOperators = input.checked ? operators.map(operator => operator.name) : [operators[0].name];
      } else if (input.checked) {
        appState.complianceOperators = [...new Set([...appState.complianceOperators, input.value])];
      } else if (appState.complianceOperators.length > 1) {
        appState.complianceOperators = appState.complianceOperators.filter(name => name !== input.value);
      } else {
        input.checked = true;
        toast('至少需要選擇一個營運商');
        return;
      }
      appState.topOperator = 'all';
      render();
      requestAnimationFrame(() => {
        const picker = el('#compliance-operator-multiselect');
        const trigger = el('#compliance-operator-trigger');
        if (picker && trigger) { picker.classList.add('open'); trigger.setAttribute('aria-expanded', 'true'); }
      });
    }));
  }
  const exceptionType = el('#exception-type');
  if (exceptionType) {
    exceptionType.value = appState.complianceException;
    exceptionType.addEventListener('change', event => { appState.complianceException = event.target.value; render(); });
  }
  const topOperator = el('#top-operator');
  if (topOperator) {
    topOperator.value = appState.topOperator;
    topOperator.addEventListener('change', event => { appState.topOperator = event.target.value; render(); });
  }
  const topAnomaly = el('#top-anomaly');
  if (topAnomaly) {
    topAnomaly.value = appState.topAnomaly;
    topAnomaly.addEventListener('change', event => { appState.topAnomaly = event.target.value; render(); });
  }
  const uploadStatus = el('#upload-status');
  if (uploadStatus) {
    uploadStatus.value = appState.uploadStatus;
    uploadStatus.addEventListener('change', event => { appState.uploadStatus = event.target.value; render(); });
  }
  const uploadRange = el('#upload-range');
  if (uploadRange) {
    uploadRange.value = appState.uploadRange;
    uploadRange.addEventListener('change', event => { appState.uploadRange = event.target.value; render(); });
  }
  const resetCompliance = el('.reset-compliance');
  if (resetCompliance) resetCompliance.addEventListener('click', () => {
    appState.compliancePeriod = 'day'; appState.complianceOperators = operators.map(operator => operator.name); appState.complianceException = 'all'; appState.topOperator = 'all'; render();
  });
  const range = el('#trip-range');
  if (range) {
    range.value = appState.range;
    range.addEventListener('change', event => {
      appState.range = event.target.value;
      el('#trip-history-content').innerHTML = renderTripHistory(appState.range, appState.tripOperator, appState.tripHistoryView);
      bindTripHistoryControls();
    });
  }
  const tripOperator = el('#trip-operator');
  if (tripOperator) {
    tripOperator.value = appState.tripOperator;
    tripOperator.addEventListener('change', event => {
      appState.tripOperator = event.target.value;
      el('#trip-history-content').innerHTML = renderTripHistory(appState.range, appState.tripOperator, appState.tripHistoryView);
      bindTripHistoryControls();
    });
  }
  bindTripHistoryControls();
  const vehiclePeriod = el('#vehicle-period');
  if (vehiclePeriod) {
    vehiclePeriod.value = appState.vehiclePeriod;
    vehiclePeriod.addEventListener('change', event => { appState.vehiclePeriod = event.target.value; render(); });
  }
  const vehicleHistoryRange = el('#vehicle-history-range');
  if (vehicleHistoryRange) {
    vehicleHistoryRange.value = appState.vehicleHistoryRange;
    vehicleHistoryRange.addEventListener('change', event => { appState.vehicleHistoryRange = event.target.value; render(); });
  }
  const inactivePageSize = el('#inactive-page-size');
  const inactiveStatus = el('#inactive-status');
  if (inactivePageSize) {
    inactivePageSize.value = appState.inactivePageSize;
    inactivePageSize.addEventListener('change', event => { appState.inactivePageSize = event.target.value; render(); });
  }
  if (inactiveStatus) {
    inactiveStatus.value = appState.inactiveStatus;
    inactiveStatus.addEventListener('change', event => { appState.inactiveStatus = event.target.value; render(); });
  }
  const applyInactiveFilter = el('#apply-inactive-filter');
  if (applyInactiveFilter) applyInactiveFilter.addEventListener('click', () => {
    toast('篩選條件已套用');
  });
}

function bindTripHistoryControls() {
  all('[data-history-view]').forEach(button => button.addEventListener('click', () => {
    appState.tripHistoryView = button.dataset.historyView;
    el('#trip-history-content').innerHTML = renderTripHistory(appState.range, appState.tripOperator, appState.tripHistoryView);
    bindTripHistoryControls();
  }));
}

function updateVehiclePeriod(period) {
  appState.vehiclePeriod = period;
  const data = vehiclePeriodData[period];
  const values = {
    label: data.label,
    active: data.active,
    licensedInactive: data.licensedInactive,
    unregistered: data.unregistered,
    activeRateLabel: data.activeRateLabel,
    licensedTotal: data.licensedTotal,
    registrationRate: data.registrationRate,
    operatingRate: data.operatingRate,
  };
  all('[data-vehicle-bind]').forEach(node => { node.textContent = values[node.dataset.vehicleBind]; });
  const distributionDonut = el('.distribution-body .donut');
  if (distributionDonut) distributionDonut.style.setProperty('--value', data.activeRate);
}

function showModal(content, className = '') {
  el('#modal-root').innerHTML = `<div class="modal-backdrop"><section class="modal ${className}" role="dialog" aria-modal="true">${content}</section></div>`;
  const backdrop = el('.modal-backdrop');
  backdrop.addEventListener('click', event => { if (event.target === backdrop || event.target.closest('[data-close]')) closeModal(); });
  document.addEventListener('keydown', escapeModal, { once: true });
}

function escapeModal(event) { if (event.key === 'Escape') closeModal(); }
function closeModal() { el('#modal-root').innerHTML = ''; }

function showOperatorModal(row) {
  showModal(`<header><h2>${row.name} 詳情</h2><button data-close aria-label="關閉">×</button></header><dl class="detail-list"><div><dt>公司名稱</dt><dd>${row.name}</dd></div><div><dt>BR 編號</dt><dd>07093211</dd></div><div><dt>網約車營運牌照編號</dt><dd>RH-LIC-001</dd></div><div><dt>牌照有效期至</dt><dd>${row.end}</dd></div><div><dt>首次發牌日期</dt><dd>2022-06-15</dd></div><div><dt>牌照狀態</dt><dd class="positive">有效</dd></div><div><dt>公司地址</dt><dd>香港中環皇后大道中211號</dd></div><div><dt>公司董事姓名</dt><dd>陳**</dd></div><div><dt>聯絡電話</dt><dd>+852 2*** ****</dd></div></dl>`, 'detail-modal');
}

function showDriverModal(anomaly = '司機無許可證') {
  showModal(`<header><h2>詳情</h2></header><dl class="detail-list anomaly-detail-list"><div><dt>訂單號碼</dt><dd>DD-20981</dd></div><div><dt>營運商</dt><dd>營運商 A</dd></div><div><dt>車主姓名</dt><dd>陳**</dd></div><div><dt>駕駛執照號碼</dt><dd>A123****</dd></div><div><dt>異常類型</dt><dd class="negative">${anomaly}</dd></div><div><dt>最近異常時間</dt><dd>2026-08-03</dd></div><div><dt>車牌號碼</dt><dd>AB-1234</dd></div></dl>`, 'anomaly-detail-modal');
}

function showValidationModal() {
  showModal(`<header><h2>驗證結果</h2><button data-close>×</button></header><div class="validation-hero"><span>✓</span><h3>資料已成功匯入</h3><p>10,000 筆資料通過結構及欄位驗證。</p></div><div class="upload-counts"><div><span>總計</span><b>10,000</b></div><div><span>已匯入</span><b class="positive">10,000</b></div><div><span>錯誤</span><b>0</b></div></div><footer><button class="primary-btn" data-close>完成</button></footer>`);
}

function showUploadModal(saved = {}) {
  showModal(`<header><div><h2>上傳合規數據</h2><p>上傳 XLSX 或 CSV 檔案進行驗證及匯入。</p></div><button data-close>×</button></header><label class="drop-zone"><input id="compliance-file" type="file" accept=".xlsx,.xls,.csv"/><span>↥</span><strong>拖放檔案至此，或按一下瀏覽</strong><small id="selected-file-name">${saved.fileName || '支援 XLSX、XLS、CSV，最大 25 MB'}</small></label><div class="form-row"><label>營運商<select id="upload-operator"><option>所有營運商</option>${operators.map(o => `<option>${o.name}</option>`).join('')}</select></label><label>數據日期<input id="upload-date" type="date" value="${saved.date || '2026-08-01'}"/></label></div><footer><button class="secondary-btn" data-close>取消</button><button class="primary-btn confirm-upload">驗證並上傳</button></footer>`, 'upload-modal');
  el('#upload-operator').value = saved.operator || '所有營運商';
  el('#compliance-file').addEventListener('change', event => {
    if (event.target.files[0]) el('#selected-file-name').textContent = event.target.files[0].name;
  });
  el('.confirm-upload').addEventListener('click', () => {
    const selectedOperator = el('#upload-operator').value;
    const selectedDate = el('#upload-date').value;
    const selectedFile = el('#compliance-file').files[0]?.name || saved.fileName || 'compliance_august_2026.xlsx';
    showUploadReview({ operator: selectedOperator, date: selectedDate, fileName: selectedFile });
  });
}

function showUploadReview(upload) {
  showModal(`<header class="review-header"><div class="review-heading"><span>!</span><div><h2>上傳完成 — 需要審查</h2><p>數據已成功上傳，但部分記錄未能通過驗證。</p></div></div><button data-close>×</button></header>
    <div class="upload-review-body">
      <div class="upload-file-summary"><div><span>檔案</span><b>${upload.fileName}</b></div><div><span>上傳時間</span><b>2026年8月3日 · 14:32</b></div><div><span>批次編號</span><b>CMP-260803-1432</b></div></div>
      <div class="review-counts"><div><span>總行數</span><b>10,000</b></div><div><span>通過驗證行數</span><b>9,977</b></div><div><span>警告</span><b>0</b></div><div><span>錯誤行數</span><b>23</b></div></div>
      <div class="review-checks"><p><span>必要數據均齊全</span><b class="failed">×</b></p><p><span>已檢查重複記錄</span><b class="passed">✓</b></p></div>
      <div class="review-issues"><strong>主要問題</strong><p>13 個駕駛日期 · 6 個重複記錄</p><p>4 個未能識別的營運商編號</p></div>
      <label class="review-acknowledge"><input id="review-acknowledge" type="checkbox" checked/><span>我已審查驗證結果</span></label>
    </div>
    <footer><button class="secondary-btn" id="choose-again">重新選擇</button><button class="primary-btn" id="continue-import">匯入</button></footer>`, 'review-modal');
  el('#choose-again').addEventListener('click', () => showUploadModal(upload));
  const importButton = el('#continue-import');
  el('#review-acknowledge').addEventListener('change', event => { importButton.disabled = !event.target.checked; });
  importButton.addEventListener('click', () => showUploadConfirmation(upload));
}

function showUploadConfirmation(upload) {
  const [year, month, day] = upload.date.split('-');
  const displayDate = `${day}/${month}/${year}`;
  showModal(`<div class="confirm-upload-content"><h2>確認上傳資訊</h2><p>系統已自動從檔案名稱中偵測以下資訊，請確認後繼續。</p><div class="auto-detected-card"><span>AUTO-DETECTED INFO</span><strong>The <b>2nd</b> upload for the date of <b>${displayDate}</b></strong></div><button class="confirm-upload-btn" id="finish-upload">確認</button></div>`, 'confirm-modal');
  el('#finish-upload').addEventListener('click', () => { closeModal(); appState.complianceTab = 'history'; render(); toast('已匯入 9,977 行，另有 23 行需要覆查'); });
}

let toastTimer;
function toast(message) {
  const root = el('#toast-root');
  root.textContent = message; root.classList.add('show'); clearTimeout(toastTimer);
  toastTimer = setTimeout(() => root.classList.remove('show'), 2400);
}

document.addEventListener('click', event => {
  const viewButton = event.target.closest('[data-view]');
  if (!viewButton) return;
  const requestedView = viewButton.dataset.view;
  if (requestedView === appState.view) return;
  appState.view = requestedView;
  render(); el('#main').focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.addEventListener('click', event => {
  const picker = el('#compliance-operator-multiselect');
  if (!picker || event.target.closest('#compliance-operator-multiselect')) return;
  picker.classList.remove('open');
  const trigger = el('#compliance-operator-trigger');
  if (trigger) trigger.setAttribute('aria-expanded', 'false');
});

el('.collapse-btn').addEventListener('click', () => {
  appState.sidebarCollapsed = !appState.sidebarCollapsed;
  el('#app').classList.toggle('sidebar-collapsed', appState.sidebarCollapsed);
  el('.sidebar').classList.toggle('is-collapsed', appState.sidebarCollapsed);

  const button = el('.collapse-btn');
  const label = appState.sidebarCollapsed ? '展開功能選單' : '收起功能選單';
  button.textContent = appState.sidebarCollapsed ? '›' : '‹';
  button.setAttribute('aria-label', label);
  button.setAttribute('aria-expanded', String(!appState.sidebarCollapsed));
  button.title = label;
});

el('#language-select').addEventListener('change', event => {
  appState.language = event.target.value;
  applyLanguage(appState.language);
});

render();
